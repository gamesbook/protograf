echo -e "\nCreating PDFs for all examples (except those in manual)"
echo ""
mkdir -p /tmp/demo
echo -e "\nAll examples output is saved to /tmp/demo"
# ---- examples: simple

python various/objects.py --no-png -d /tmp/demo
#python various/rolling.py --no-png -d /tmp/demo
#python various/world_clocks.py --no-png -d /tmp/demo

echo -e "\nDone!"
