"""
`counters1` example for protograf

Written by: Derek Hohls
Created on: 22 September 2024
"""
from protograf import *

Create()
CounterSheet()
Save()
