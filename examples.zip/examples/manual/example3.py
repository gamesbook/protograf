"""
`example3` script for protograf

Written by: Derek Hohls
Created on: 29 February 2016
"""
from protograf import *

Create()
Text(text="Hello World", x="a")  # wrong - cannot use letter for numeric!
PageBreak()
Save()
