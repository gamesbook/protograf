# -*- coding: utf-8 -*-
"""
Virtual layout examples for protograf

Written by: Derek Hohls
Created on: 19 May 2024
"""
from protograf import *

Create(filename="layouts_basic_rectangular.pdf",
       paper="A8",
       margin_left=0.5,
       margin_right=0.3,
       margin_bottom=0.2,
       margin_top=0.5,
       font_size=8,
       stroke_width=0.5)

header = Common(x=0, y=0, font_size=8, align="left")
a_circle = circle(
    x=0, y=0, radius=0.5, label="{{sequence}}//{{col}}-{{row}}", label_size=6)

# ---- regular

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: NW->south (2x3)")
rect = RectangularLocations(cols=2, rows=3, start="NW", direction="south")
Layout(rect, shapes=[circle(x=0, y=0, diameter=1)], debug='cr')
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: NW->east")
rect = RectangularLocations(cols=3, rows=3, start="NW", direction="east")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: NE->west")
rect = RectangularLocations(cols=3, rows=3, start="NE", direction="west")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: NE->south")
rect = RectangularLocations(cols=3, rows=3, start="NE", direction="south")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: SE->north")
rect = RectangularLocations(cols=3, rows=3, start="SE", direction="north")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: SE->west")
rect = RectangularLocations(cols=3, rows=3, start="SE", direction="west")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: SW->north")
rect = RectangularLocations(cols=3, rows=3, start="SW", direction="north")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: SW->east")
rect = RectangularLocations(cols=3, rows=3, start="SW", direction="east")
Layout(rect, shapes=[a_circle,])
PageBreak()

# ---- snake

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: NW->south: Snake")
rect = RectangularLocations(cols=3, rows=4, start="NW", direction="south", pattern="snake")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: NW->east: Snake")
rect = RectangularLocations(cols=3, rows=4, start="NW", direction="east", pattern="snake")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: NE->south: Snake")
rect = RectangularLocations(cols=3, rows=4, start="NE", direction="south", pattern="snake")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: NE->west: Snake")
rect = RectangularLocations(cols=3, rows=4, start="NE", direction="west", pattern="snake")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: SE->north: Snake")
rect = RectangularLocations(cols=3, rows=4, start="SE", direction="north", pattern="snake")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: SE->west: Snake")
rect = RectangularLocations(cols=3, rows=4, start="SE", direction="west", pattern="snake")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: SW->north: Snake")
rect = RectangularLocations(cols=3, rows=4, start="SW", direction="north", pattern="snake")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: SW->east: Snake")
rect = RectangularLocations(cols=3, rows=4, start="SW", direction="east", pattern="snake")
Layout(rect, shapes=[a_circle,])
PageBreak()

# ---- outer

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: NW->east: Outer")
rect = RectangularLocations(cols=3, rows=4, start="NW", direction="east", pattern="outer")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: NW->south: Outer")
rect = RectangularLocations(cols=3, rows=4, start="NW", direction="south", pattern="outer")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: NE->west: Outer")
rect = RectangularLocations(cols=3, rows=4, start="NE", direction="west", pattern="outer")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: NE->south: Outer")
rect = RectangularLocations(cols=3, rows=4, start="NE", direction="south", pattern="outer")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: SE->north: Outer")
rect = RectangularLocations(cols=3, rows=4, start="SE", direction="north", pattern="outer")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: SE->west: Outer")
rect = RectangularLocations(cols=3, rows=4, start="SE", direction="west", pattern="outer")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: SW->east: Outer")
rect = RectangularLocations(cols=3, rows=4, start="SW", direction="east", pattern="outer")
Layout(rect, shapes=[a_circle,])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: SW->north: Outer")
rect = RectangularLocations(cols=3, rows=4, start="SW", direction="north", pattern="outer")
Layout(rect, shapes=[a_circle,])
PageBreak()

# ---- grid and fill
small_circle = circle(radius=0.15, fill="tomato")

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: gridlines; fill")
rct = RectangularLocations(cols=3, rows=5, start="NE", direction="west")
Layout(
   rct,
   gridlines='*',
   gridlines_fill="aqua",
   gridlines_stroke="gold",
   gridlines_stroke_width=2,
   shapes=[small_circle])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text='Rect.Locations: gridlines "o"')
rct = RectangularLocations(cols=3, rows=5, start="NE", direction="west")
Layout(
   rct,
   gridlines='o',
   gridlines_stroke="gold",
   gridlines_stroke_width=2,
   shapes=[small_circle])
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: gridlines: square")
rct = RectangularLocations(cols=4, rows=4, start="NE", direction="west")
Layout(
   rct,
   gridlines='d n',
   gridlines_stroke="gold",
   gridlines_stroke_width=2,
   shapes=[small_circle])
PageBreak()

# ---- layout with filled shape
red_circle = circle(radius=0.33, fill="tomato")
gold_circle = circle(radius=0.33, fill="gold")

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: col shapes")
rct = RectangularLocations(facing='north', y=1, x=1, side=.66, cols=4, rows=6)
Layout(rct, shapes=[gold_circle])
Layout(rct, cols=[1,4], shapes=[red_circle], debug='c')
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=header, text="Rect.Locations: row shapes")
rct = RectangularLocations(facing='north', y=1, x=1, side=.66, cols=4, rows=6)
Layout(rct, shapes=[gold_circle])
Layout(rct, rows=[1,3,5], shapes=[red_circle], debug='r')
# PageBreak()

Save(
    output='png',
    dpi=300,
    directory="../docs/source/images/layouts",
    names=[
        "rect_locs_reg_nw_S", "rect_locs_reg_nw_E",
        "rect_locs_reg_ne_W", "rect_locs_reg_ne_S",
        "rect_locs_reg_se_N", "rect_locs_reg_se_W",
        "rect_locs_reg_sw_N", "rect_locs_reg_sw_E",

        "rect_locs_snake_nw_S", "rect_locs_snake_nw_E",
        "rect_locs_snake_ne_S", "rect_locs_snake_ne_W",
        "rect_locs_snake_se_N", "rect_locs_snake_se_W",
        "rect_locs_snake_sw_N", "rect_locs_snake_sw_E",

        "rect_locs_outer_nw_E", "rect_locs_outer_nw_S",
        "rect_locs_outer_ne_W", "rect_locs_outer_ne_S",
        "rect_locs_outer_se_N", "rect_locs_outer_se_W",
        "rect_locs_outer_sw_E", "rect_locs_outer_sw_N",

        "rect_locs_grid_fill",
        "rect_locs_grid_orth",
        "rect_locs_grid_diag",

        "rect_locs_shape_cols",
        "rect_locs_shape_rows",
    ]
)
