"""
Show customised Rectangle for protograf

Written by: Derek Hohls
Created on: 19 September 2024
"""

from protograf import *

Create(filename="customised_rectangle.pdf",
       paper="A8",
       margin_left=0.5,
       margin_right=0.3,
       margin_bottom=0.2,
       margin_top=0.5,
       font_size=8,
       stroke_width=0.5)

txt = Common(x=0, y=0, font_size=8, align="left")

Text(common=txt, text="Rectangle START...")
PageBreak()

# ---- centre
Blueprint()
Text(common=txt, text="Rectangle: cx=2, cy=3")
Rectangle(cx=2, cy=3)
PageBreak()

# ---- notches
Blueprint()
Text(common=txt, text="Rectangle: notches")
Rectangle(
    x=2, y=1,
    height=2, width=1,
    notch=0.25,
    label="notch:0.5",
    label_size=5,
    )
Rectangle(
    x=1, y=4,
    height=1, width=2,
    notch_y=0.25,
    notch_x=0.5,
    notch_directions="NW SE",
    label="notch:.25/.5 loc: NW, SE",
    label_size=5,
    )
PageBreak()

# ---- dot_cross
Blueprint()
Text(common=txt, text="Rectangle: dot & cross")
Rectangle(height=3, width=2, cross=0.75, dot=0.15)
PageBreak()

# ---- hatches
Blueprint()
Text(common=txt, text="Rectangle: hatches + directions")
htch = Common(height=1.5, width=1, hatches_count=5,
              hatches_stroke_width=0.5, hatches_stroke="red")

Rectangle(common=htch, x=0, y=0,  hatches='w', label="W")
Rectangle(common=htch, x=1.5, y=0, hatches='e', label="E")
Rectangle(common=htch, x=3, y=0, hatches='ne', label="NE\nSW")

Rectangle(common=htch, x=1.5, y=2, hatches='n', label="N")
Rectangle(common=htch, x=0, y=2,  hatches='s', label="S")
Rectangle(common=htch, x=3, y=2, hatches='nw', label="NW\nSE")

Rectangle(common=htch, x=0, y=4, label="all")
Rectangle(common=htch, x=1.5, y=4, hatches='o', label="O")
Rectangle(common=htch, x=3, y=4, hatches='d', label="D")

PageBreak()

# ---- hatches - variable
Blueprint()
Text(common=txt, text="Rectangle: hatches; variable")
Rectangle(
    x=0.5, y=1,
    height=4, width=3,
    hatches=[('e', 2), ('d', 5)],
    hatches_stroke_width=0.5,
    hatches_stroke="red")
PageBreak()

# ---- perbii
Blueprint()
Text(common=txt, text="Rectangle: perbii + directions")
prbs = Common(height=2, width=1,
              perbii_stroke_width=2,
              perbii_stroke="red")
Rectangle(common=prbs, x=0.5, y=1, perbii='n', label="N")
Rectangle(common=prbs, x=2.5, y=1, perbii='s', label="S")
Rectangle(common=prbs, x=0.5, y=4, perbii='w', label="W")
Rectangle(common=prbs, x=2.5, y=4, perbii='e', label="E")

PageBreak()

# ---- radii
Blueprint()
Text(common=txt, text="Rectangle: radii + directions")
rds = Common(height=2, width=1,
             radii_stroke_width=2,
             radii_stroke="red")
Rectangle(common=rds, x=0.5, y=1, radii='nw', label="NW")
Rectangle(common=rds, x=2.5, y=1, radii='ne', label="NE")
Rectangle(common=rds, x=0.5, y=4, radii='sw', label="SW")
Rectangle(common=rds, x=2.5, y=4, radii='se', label="SE")

PageBreak()

# ---- rounding
Blueprint()
Text(common=txt, text="Rectangle: rounding; hatches")
rct = Common(x=0.5, height=1.5, width=3.0, stroke_width=.5,
             hatches_stroke="red", hatches='o')
Rectangle(common=rct, y=1, rounding=0.1, hatches_count=10)
Rectangle(common=rct, y=4, rounding=0.5, hatches_count=3)
# Rectangle(common=rct, y=4, rounding=0.5, hatches_count=15)  # THIS FAILS!
PageBreak()

# ---- chevron
Blueprint()
Text(common=txt, text="Rectangle: chevron")
styles = Common(
    height=2, width=1,
    font_size=4)
Rectangle(
    common=styles,
    x=3, y=2,
    chevron='N',
    chevron_height=0.5,
    label="chevron:N:0.5",
    title="title-N",
    heading="head-N",
    )
Rectangle(
    common=styles,
    x=0, y=2,
    chevron='S',
    chevron_height=0.5,
    label="chevron:S:0.5",
    title="title-S",
    heading="head-S",
    )
Rectangle(
    common=styles,
    x=2, y=3.5,
    chevron='W',
    chevron_height=0.5,
    label="chevron:W:0.5",
    title="title-W",
    heading="head-W",
    )
Rectangle(
    common=styles,
    x=1, y=0.5,
    chevron='E',
    chevron_height=0.5,
    label="chevron:E:0.5",
    title="title-E",
    heading="head-E",
    )
PageBreak()

# ---- peak
Blueprint()
Text(common=txt, text="Rectangle: peaks")
Rectangle(x=1, y=1, width=2, height=1,
          peaks=[("*", 0.2)], font_size=6,
          label="peaks = *")
Rectangle(x=1, y=3, width=2, height=1.5,
          peaks=[("s", 1), ("e", 0.25)], font_size=6,
          label="peaks = s,e")
PageBreak()

# ---- rotation
Blueprint()
Text(common=txt, text="Rectangle: red => rotation 45\u00B0")
Rectangle(cx=2, cy=3, width=1.5, height=3, dot=0.06)
Rectangle(cx=2, cy=3, width=1.5, height=3, fill=None,
          stroke="red", stroke_width=.3, rotation=45, dot=0.04)
PageBreak()

# ---- notch_style
Blueprint()
Text(common=txt, text="Rectangle : Notch Styles")
styles = Common(height=0.8, width=3.5, x=0.25, stroke_width=0.5,
                notch=0.2, label_size=7, fill="lightsteelblue")
Rectangle(common=styles, y=0, notch_style='snip', label='Notch: snip (s)')
Rectangle(common=styles, y=1, notch_style='step', label='Notch: step (t)')
Rectangle(common=styles, y=2, notch_style='fold', label='Notch: fold (d)')
Rectangle(common=styles, y=3, notch_style='flap', label='Notch: flap (p)')
Rectangle(common=styles, y=4, notch_style='bite', label='Notch: bite (b)')
Rectangle(common=styles, y=5, notch_style='arch', label='Notch: arch (a)')
PageBreak()

# ---- borders
Blueprint(stroke_width=0.5)
Text(common=txt, text="Rectangle: borders")
Rectangle(
    x=0.5, y=3.5, height=2, width=3, stroke=None, fill="gold",
    borders=[
        ("n", 3, "lightsteelblue", True),
        ("s", 2),
    ]
)
Rectangle(
    x=0.5, y=0.5, height=2, width=3, stroke_width=1.9,
    borders=[
        ("w", 2, "gold"),
        ("n", 2, "chartreuse", True),
        ("e", 2, "tomato", [0.1, 0.2]),
    ]
)
PageBreak()

# ---- slices
Blueprint(stroke_width=0.5)
Text(common=txt, text="Rectangle: slices")
Rectangle(x=1, y=0.5, slices=['tomato', 'aqua'], fill=None)
Rectangle(
    x=3, y=0.5,
    slices=['#D7D8D5', '#7E7347'],
    fill=None,
    centre_shape=square(side=0.8, fill_stroke="#BEBC9D"))
Rectangle(
    x=1, y=2,
    height=1.5, width=1.5,
    slices=['tomato', 'aqua', 'gold', 'chartreuse'],
    fill=None)
Rectangle(
    x=1, y=4,
    height=2, width=3,
    slices=['#FDAE74', '#F6965F', '#C66A3D', '#F6965F'],
    slices_line=1.25,
    slices_stroke="silver",
    fill=None)
PageBreak()

# ---- slices - custom
Blueprint(stroke_width=0.5)
Text(common=txt, text="Rectangle: slices - custom")
Rectangle(
    x=1, y=2,
    height=2, width=4,
    slices=['#555656', '#555656', '#767982', '#555656'],
    slices_line=4,
    slices_stroke="#767982",
    rotation=90)
Rectangle(
    x=0, y=3,
    height=2, width=2,
    slices=['#767982', '#636C73', '#555656', '#636C73'],
    slices_line=2,
    slices_line_mx=0.5,
    slices_stroke="#767982")
PageBreak()

# ---- prows
Blueprint(stroke_width=0.5)
Text(common=txt, text='Prow: defaults+')
Rectangle(
    cx=1, cy=1, width=1, height=1,
    prows=[("e",)]
)
Rectangle(
    cx=1, cy=3, width=1, height=1,
    prows=[("n", 0.5)]
)
Rectangle(
    cx=3, cy=3, width=1, height=1,
    fill="silver",
    prows=[("*", -0.1)]
)
Rectangle(
    cx=1, cy=5, width=1, height=1,
    prows=[("*", 0.8, (0.3, 0.45))]
)
Rectangle(
    cx=3, cy=5, width=1, height=1,
    fill="gold",
    prows=[("*", -0.8, (-0.3, -0.45))]
)
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=txt, text='Prow: "inwards" (star)')
Rectangle(
    x=1.5, y=2, width=1, height=2,
    fill="gold",
    stroke="orange", stroke_width=2,
    prows=[
        ("n", 2, (0.22, 0.22)),
        ("s", 2, (0.22, 0.22)),
        ("e", 1.5, (0.33, 0.33)),
        ("w", 1.5, (0.33, 0.33)),
    ]
)
PageBreak()

Blueprint(stroke_width=0.5)
Text(common=txt, text='Prow: "outwards" (ship)')
Rectangle(
    x=1.5, y=2, width=1, height=3,
    fill="silver",
    stroke="darkgrey", stroke_width=2,
    prows=[
        ("n", 1, (0.44, 0.44)),
        ("s", 0.2, (0.2, 0.2)),
    ]
)
PageBreak()

# ---- corners_style
Blueprint()
Text(common=txt, text="Rectangle : Corners Styles")
styles = Common(
    height=1.0, width=3.5, x=0.25,
    label_size=7, fill="lightsteelblue",
    corners=0.4,
    corners_stroke="gold",
    corners_fill='red',
)
Rectangle(common=styles, y=0, label='Corners (default)')
Rectangle(common=styles, y=1.25,
          corners_style='line',
          corners_stroke_width=2,
          label='Corners: line (l)')
Rectangle(common=styles, y=2.5, corners_style='triangle', label='Corner: triangle (t)')
Rectangle(common=styles, y=3.75, corners_style='curve', label='Corner: curve (s)')
Rectangle(common=styles, y=5, corners_style='photo', label='Corner: photo (p)')
PageBreak()

# ---- stripes
Text(common=txt, text="Rectangle: stripes")
Blueprint(stroke_width=0.5)
strp = Common(
    height=1.75, width=1.25,
    stripes=3,
    stripes_breadth=0.2,
    stripes_stroke="red",
    stripes_fill="gold"
)
Rectangle(common=strp, x=0, y=0, stripes_directions='w', label="W")
Rectangle(common=strp, x=1.5, y=0, stripes_directions='e', label="E")
Rectangle(common=strp, x=3, y=0, stripes_directions='ne', label="ne/sw")
Rectangle(common=strp, x=1.5, y=2, stripes_directions='s', label="S")
Rectangle(common=strp, x=0, y=2, stripes_directions='n', label="N")
Rectangle(common=strp, x=3, y=2, stripes_directions='nw', label="nw/se")
Rectangle(common=strp, x=0, y=4, stripes_directions='*', label="all")
Rectangle(common=strp, x=1.5, y=4, stripes_directions='o', label="O")
Rectangle(common=strp, x=3, y=4, stripes_directions='d', label="D")
PageBreak()

# ---- stripes_flush
Text(common=txt, text="Rectangle: stripes (flush)")
Blueprint(stroke_width=0.5)
strp = Common(
    height=1.75, width=1.25,
    stripes=3,
    stripes_breadth=0.2,
    stripes_stroke="red",
    stripes_fill="aqua",
    stripes_flush=True
)
Rectangle(common=strp, x=0, y=0, stripes_directions='w', label="W")
Rectangle(common=strp, x=1.5, y=0, stripes_directions='e', label="E")
Rectangle(common=strp, x=3, y=0, stripes_directions='ne', label="ne/sw")
Rectangle(common=strp, x=1.5, y=2, stripes_directions='', label="S")
Rectangle(common=strp, x=0, y=2, stripes_directions='n', label="N")
Rectangle(common=strp, x=3, y=2, stripes_directions='nw', label="nw/se")
Rectangle(common=strp, x=0, y=4,  stripes_directions='*', label="all")
Rectangle(common=strp, x=1.5, y=4, stripes_directions='o', label="O")
Rectangle(common=strp, x=3, y=4, stripes_directions='d', label="D")
PageBreak()

# ---- band - lanes & sections
Blueprint()
Text(common=txt, text="Band: Lanes & Sections")
bnd = Common(
    x=1,
    height=1,
    width=2,
    stroke_width=0.5,
)
Rectangle(
    common=bnd,
    y=1,
    lanes=2,
    no_ends=True,
 )
Rectangle(
    common=bnd,
    y=3,
    lanes=[1/3, 7/8],
    lanes_stroke="red",
    lanes_stroke_width=0.5,
    sections=3
)
Rectangle(
    common=bnd,
    y=5,
    fill="lightcyan",
    lanes=2,
    sections=[[0.5], [0.333, 0.666]],
    sections_stroke="red",
    sections_stroke_width=0.5,
    sections_dotted=True,
)

PageBreak()

# ---- END
Text(common=txt, text="Rectangle END...")

Save(
     output='png',
     dpi=300,
     directory="../docs/source/images/custom/rectangle",
     names=[
        None,
        "centre", "notch", "dot_cross",
        "hatches", "hatches_variable",
        "perbii",
        "radii",
        "rounding", "chevron",
        "peak", "rotation", "notch_style", "borders",
        "slices", "slices_custom",
        "prows_defaults", "prows_inwards", "prows_outwards",
        "corners",
        "stripes", "stripes_flush",
        "band",
        None])
